package bignumber;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BigNumberImpl implements BigNumber {

  private int number;

  private BigNumberImpl next;

  private String regex = "[+-]?[0-9]+";

  Pattern p = Pattern.compile(regex);

  // change implementation
  public BigNumberImpl(String n) {
    BigNumberImpl head = new BigNumberImpl();
    BigNumberImpl temp = head;
    int index = 0;
    while (index < n.length()) {
      temp.number = Integer.parseInt(String.valueOf(n.charAt(index)));
      if (index < n.length() - 1) {
        temp.next = new BigNumberImpl();
      }
      temp = temp.next;
      index++;
    }
    this.number = head.number;
    this.next = head.next;
  }

  public BigNumberImpl() {
    this.number = 0;
    this.next = null;
  }

  @Override
  public int length() {
    BigNumberImpl temp = this;
    int length = 0;
    while (temp != null) {
      temp = temp.next;
      length++;
    }
    return length;
  }

  @Override
  public String toString() {
    String str = "";
    BigNumberImpl temp = this;
    while (temp != null) {
      str = str + temp.number;
      temp = temp.next;
    }
    return str;
  }

  @Override
  public void shiftLeft(long shifts) {
    if ((this.next == null && this.number == 0)) {
//      System.out.println("inside if..." + number);
    } else if (shifts < 0) {
      this.shiftRight(Math.abs(shifts));
    } else {
      BigNumberImpl temp = this;
      while (temp.next != null) {
        temp = temp.next;
      }

      BigNumberImpl currentNode = temp;
      long count = shifts;
      while (count > 0) {
        currentNode.next = new BigNumberImpl();
        currentNode = currentNode.next;
        count--;
      }

      // TODO - check if all 0s and make it single 0
    }
  }

  @Override
  public void shiftRight(long shifts) {
    if ((this.next == null && this.number == 0)) {
//      System.out.println("inside if..." + number);
    } else if (shifts < 0) {
      this.shiftLeft(Math.abs(shifts));
    } else {
      int currentLength = this.length();
      if (currentLength <= shifts) {
        number = 0;
        next = null;
      } else {
        long reqLen = currentLength - shifts;
        BigNumberImpl temp = this;
        while (reqLen - 1 > 0) {
          temp = temp.next;
          reqLen--;
        }
        temp.next = null;
      }
    }
  }

  // rewrite this
  @Override
  public void addDigit(int digit) {
    if (digit > 9 && digit < 0) {
      throw new IllegalArgumentException("The digit should be a single non negative integer.");
    }

    BigNumberImpl temp = addTwoNumbers(this, new BigNumberImpl(String.valueOf(digit)));
    this.number = temp.number;
    this.next = temp.next;
  }


  // this is wrong implement from right most - checkkk
  @Override
  public int getDigitAt(int index) {
    int currentLength = this.length();
    int digit = 0;
    int currentIndex = (currentLength - index);
    if (currentIndex > currentLength || currentIndex <= 0) {
      throw new IllegalArgumentException("The given index is not valid.");
    }
    BigNumberImpl current = this;
    int count = 1;
    while (current != null) {
      if (count == currentIndex) {
        return current.number;
      }
      count++;
      current = current.next;
    }
    return digit;
  }

//  @Override
//  public int compareTo(BigNumber that) {
//    return 0;
//  }

  // check for negative cases -  change implementation this fails
  @Override
  public int compareTo(BigNumber newNumber) {
    if (this.length() > newNumber.length()) {
      return 1;
    } else if (this.length() < newNumber.length()) {
      return -1;
    } else {
      return 0;
    }
  }

  @Override
  public BigNumber copy() {
    BigNumber newCopy = new BigNumberImpl(this.toString());
    return newCopy;
  }

  @Override
  public BigNumber add(BigNumber other) {
    BigNumber test = addTwoNumbers(this, other);
    return test;
  }

  private BigNumberImpl addTwoNumbers(BigNumberImpl l1, BigNumber list2) {
    BigNumberImpl l2 = (BigNumberImpl) list2;
    int len1 = l1.length();
    int len2 = l2.length();

    /*If the lists are not same size, padd the smaller one with zeros on the left.*/
    if (len1 < len2) {
      l1 = paddWithZeros(l1, len2 - len1);
    } else if (len2 < len1) {
      l2 = paddWithZeros(l2, len1 - len2);
    }
    /* will begin with 0 in the list. Treat this 0 as you carry */
    BigNumberImpl result = new BigNumberImpl("0");

    result = addTwoNumbersUtil(l1, l2, result);

    /*if the carry is 0 for the first digits in the lists, result.val will be zero. So omit that 0 node*/
    if (result.number == 0) {
      return result.next;
    }
    return result;
  }

  private BigNumberImpl paddWithZeros(BigNumberImpl node, int lenDiff) {

    while (lenDiff > 0) {

      BigNumberImpl newNode = new BigNumberImpl("0");
      newNode.next = node;
      node = newNode;

      lenDiff--;
    }
    return node;
  }

  private BigNumberImpl addTwoNumbersUtil(BigNumberImpl l1, BigNumberImpl l2,
      BigNumberImpl result) {

    if (l1 == null && l2 == null) {
      return result;

    } else {
      result = addTwoNumbersUtil(l1.next, l2.next, result);

      int sum = l1.number + l2.number + result.number;
      int carry = sum / 10;
      sum = sum % 10;
      result.number = sum;
      BigNumberImpl carryNode = new BigNumberImpl(String.valueOf(carry));
      carryNode.next = result;
      result = carryNode;

      return result;

    }


  }

}


