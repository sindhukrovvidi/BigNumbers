package bignumber;

public interface BigNumber {

  int length();

  void shiftLeft(long shifts);

  void shiftRight(long shifts);

  void addDigit(int digit);

  String getDigitAt(int index);

}
