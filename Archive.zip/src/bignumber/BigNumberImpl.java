package bignumber;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BigNumberImpl implements BigNumber {

  private String number;

  private BigNumberImpl next;

  private String regex = "[+-]?[0-9]+";

  Pattern p = Pattern.compile(regex);

  public BigNumberImpl(String  n) {
    Matcher m = p.matcher(n);
    if(!(m.find() && m.group().equals(n))) {
      throw new IllegalArgumentException("Not a valid big number.");
    }
    this.number = n;
    this.next = null;
  }

  public BigNumberImpl() {
    this.number = "0";
    this.next = null;
  }

  @Override
  public int length() {
    BigNumberImpl temp = this;
    int length = 0;
    while (temp != null) {
      temp = temp.next;
      length++;
    }
    return length;
  }

  @Override
  public String toString() {
    String str = "";
    BigNumberImpl temp = this;
    while (temp != null) {
      str = str + temp.number;
      temp = temp.next;
    }
    return str;
  }

  @Override
  public void shiftLeft(long shifts) {
    if ((this.next == null && this.number == "0")) {
//      System.out.println("inside if..." + number);
    } else if (shifts < 0) {
      this.shiftRight(Math.abs(shifts));
    } else {
      BigNumberImpl temp = this;
      while (temp.next != null) {
        temp = temp.next;
      }

      BigNumberImpl currentNode = temp;
      long count = shifts;
      while (count > 0) {
        currentNode.next = new BigNumberImpl();
        currentNode = currentNode.next;
        count--;
      }

      // TODO - check if all 0s and make it single 0
    }
  }

  @Override
  public void shiftRight(long shifts) {
    if ((this.next == null && this.number == "0")) {
//      System.out.println("inside if..." + number);
    } else if (shifts < 0) {
      this.shiftLeft(Math.abs(shifts));
    } else {
      int currentLength = this.length();
      if (currentLength <= shifts) {
        number = "0";
        next = null;
      } else {
        long reqLen = currentLength - shifts;
        BigNumberImpl temp = this;
        while (reqLen - 1 > 0) {
          temp = temp.next;
          reqLen--;
        }
        temp.next = null;
      }
    }
  }

  @Override
  public void addDigit(int digit) {
    if (digit > 9 && digit < 0) {
      throw new IllegalArgumentException("The digit should be a single non negative integer.");
    }
    BigNumberImpl temp = this;
    while (temp.next != null) {
      temp = temp.next;
    }
    temp.next = new BigNumberImpl(String.valueOf(digit));
  }


  // this is wrong implement from right most - checkkk
  @Override
  public String getDigitAt(int index) {
    int currentLength = this.length();
    String digit = "0";
    int currentIndex = (currentLength - index);
    if (currentIndex > currentLength  || currentIndex <= 0) {
      throw new IllegalArgumentException("The given index is not valid.");
    }
    BigNumberImpl current = this;
    int count = 1;
    while (current != null) {
      if (count == currentIndex) {
        return current.number;
      }
      count++;
      current = current.next;
    }
    return digit;
  }
}
