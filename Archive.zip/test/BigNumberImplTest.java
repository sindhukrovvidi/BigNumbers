
import static org.junit.Assert.assertEquals;

import bignumber.BigNumber;
import bignumber.BigNumberImpl;
import org.junit.Test;

public class BigNumberImplTest {

  @Test
  public void testLeftShift() {
    BigNumber num = new BigNumberImpl();
//    System.out.println("In test case...." + num);
    num.shiftLeft(1);
    num.toString();
    assertEquals("0", num.toString());
    assertEquals(1, num.length());
    num.addDigit(1);
    assertEquals("01", num.toString());
    num.shiftLeft(10);
    assertEquals("010000000000", num.toString());
    num.addDigit(7);
    assertEquals("0100000000007", num.toString());
    assertEquals("7", num.getDigitAt(0));
    assertEquals("0", num.getDigitAt(1));
//    assertEquals("0", num.getDigitAt(13));
    assertEquals("1", num.getDigitAt(11));
    assertEquals(13, num.length());
    num.shiftRight(1);
    assertEquals("010000000000", num.toString());


    num.shiftRight(3);
    assertEquals("010000000", num.toString());

//    num.getDigitAt(5);
    assertEquals("0", num.getDigitAt(2));

//    num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);
  }



}
