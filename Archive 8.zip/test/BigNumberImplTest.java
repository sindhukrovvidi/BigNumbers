
import static org.junit.Assert.assertEquals;

import bignumber.BigNumber;
import bignumber.BigNumberImpl;
import java.math.BigInteger;
import org.junit.Test;

public class BigNumberImplTest {

  @Test
  public void testLeftShift() {
    BigNumber num = new BigNumberImpl();
    BigNumber num2 = new BigNumberImpl();
//    System.out.println("In test case...." + num);
    num.shiftLeft(1);
    num.toString();
    assertEquals("0", num.toString());
    assertEquals(1, num.length());
    num.addDigit(1);
    assertEquals("01", num.toString());
    num.shiftLeft(10);
    assertEquals("010000000000", num.toString());
    num.addDigit(7);
    assertEquals("0100000000007", num.toString());
    assertEquals("7", num.getDigitAt(0));
    assertEquals("0", num.getDigitAt(1));
//    assertEquals("0", num.getDigitAt(13));
    assertEquals("1", num.getDigitAt(11));
    assertEquals(13, num.length());
    num.shiftRight(1);
    assertEquals("010000000000", num.toString());


    num.shiftRight(3);
    assertEquals("010000000", num.toString());

//    num.getDigitAt(5);
    assertEquals("0", num.getDigitAt(2));
    assertEquals(0, num.compareTo((BigNumberImpl) num));
    assertEquals(1, num.compareTo((BigNumberImpl) num2));
//    System.out.println(num);

//    num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);
  }

  @Test
  public void testBigNuberConstructor() {
    BigNumber num = new BigNumberImpl("32411");
    System.out.println(num);
  }

  @Test
  public void testLeftShift1() {
    BigNumber num = new BigNumberImpl("32419");
    System.out.println(num);
//    System.out.println(num);

//    num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);num.shiftLeft(1);
  }

  @Test
  public void testaddDigit() {
    BigNumber num = new BigNumberImpl();
    num.shiftLeft(3);
    assertEquals("0", num.toString());
    num.addDigit(3);
    assertEquals("3", num.toString());
    num.shiftLeft(3);
    assertEquals("3000", num.toString());
    num.addDigit(3);
    assertEquals("3003", num.toString());
    num.addDigit(3);
    num.addDigit(3);
    num.addDigit(3);
    num.addDigit(3);
    num.addDigit(3);
    assertEquals(4, num.length());
    assertEquals("3018", num.toString());
  }

  @Test
  public  void testCopy() {
    BigNumber num = new BigNumberImpl();
    BigNumber num2 = new BigNumberImpl();
//    System.out.println("In test case...." + num);
    num.shiftLeft(1);
    num.toString();
//    assertEquals("0", num.toString());
    assertEquals(1, num.length());
    num.addDigit(15);
//    assertEquals("1", num.toString());
    num.shiftLeft(10);
//    assertEquals("10000000000", num.toString());
    num.addDigit(7);
//    assertEquals("100000000007", num.toString());
//    assertEquals("7", num.getDigitAt(0));
//    assertEquals("0", num.getDigitAt(1));
//    assertEquals("0", num.getDigitAt(13));
//    assertEquals("1", num.getDigitAt(11));
//    assertEquals(13, num.length());
    num.shiftRight(1);
//    assertEquals("1000000000", num.toString());


    num.shiftRight(3);
//    assertEquals("10000000", num.toString());
//    assertEquals(num, num.copy());;
  }

  @Test
  public void testAddTwoBig() {
    BigNumber num = new BigNumberImpl();
    num.addDigit(3);
    num.addDigit(8);
    num.shiftLeft(9);
    assertEquals("11000000000", num.toString());
    num.shiftRight(8);
    assertEquals("110", num.toString());
    num.shiftRight(1);
    assertEquals("11", num.toString());
    num.shiftRight(1);
    assertEquals("1", num.toString());
  }

}
