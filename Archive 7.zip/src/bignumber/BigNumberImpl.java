package bignumber;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class BigNumberImpl implements BigNumber {

  private int number;

  private int length;

  private BigNumberImpl next;

  private BigNumberImpl tail;

  private BigNumberImpl prev;

//  private String regex = "[+-]?[0-9]+";
//
//  Pattern p = Pattern.compile(regex);

  // change implementation
  public BigNumberImpl(String n) {
    BigNumberImpl head = new BigNumberImpl();
    BigNumberImpl temp = head;
    BigNumberImpl prevTemp = new BigNumberImpl();
    int index = 0;
    while (index < n.length()) {
      temp.number = Integer.parseInt(String.valueOf(n.charAt(index)));
      if (index < n.length() - 1) {
        temp.next = new BigNumberImpl();
        this.tail = temp.next;
      } else if(n.length() == 1) {
        this.tail = head;
      }
      prevTemp.next = temp;
      temp.prev = prevTemp;
      prevTemp = prevTemp.next;
      temp = temp.next;
      index++;
    }
    head.prev = null;
    this.number = head.number;
    this.next = head.next;
    this.length = n.length();
    this.prev = null;


//    BigNumberImpl head = new BigNumberImpl();
//    BigNumberImpl tail = new BigNumberImpl();
//    BigNumberImpl temp = head;
//    BigNumberImpl prevTemp = new BigNumberImpl();
//    int index = 0;
//    while (index < n.length()) {
//        temp.number = Integer.parseInt(String.valueOf(n.charAt(index)));
//        temp.next = new BigNumberImpl();
//        tail = temp;
//        temp.prev = temp;
//        temp = temp.next;
//        index++;
//    }
//    head.prev = null;
//    this.number = head.number;
//    this.next = head.next;
//    this.length = n.length();
//    this.tail = tail;
  }

  public BigNumberImpl() {
    this.number = 0;
    this.next = null;
    this.length = 1;
    this.tail = this;
    this.prev = null;
  }


  @Override
  public String toString() {
    String str = "";
    BigNumberImpl temp = this;
    while (temp != null) {
      str = str + temp.number;
      temp = temp.next;
    }
    return str;
  }

  @Override
  public int length() {
//    System.out.println("String.. " + this.toString());
//    BigNumberImpl temp = this;
//    int length = 0;
//    while (temp != null) {
//      System.out.println("String value.. " + temp.number);
//      temp = temp.next;
//      length++;
//    }
//    return length;
//    if(this.next == null)
//      return 1;
//    return 1 + this.next.length();
    return this.length;

  }

  @Override
  public void shiftLeft(long shifts) {
    if ((this.next == null && this.number == 0)) {

    } else if (shifts < 0) {
      this.shiftRight(Math.abs(shifts));
    } else {
      long count = shifts;
      while(count > 0){
       tail.next = new BigNumberImpl();
       tail = tail.next;
       count--;
      }
      this.length += shifts;
    }
  }

  @Override
  public void shiftRight(long shifts) {
    if ((this.next == null && this.number == 0)) {

    } else if (shifts < 0) {
      this.shiftLeft(Math.abs(shifts));
    } else {

      int currentLength = length;
      if (currentLength <= shifts) {
        number = 0;
        next = null;
        length = 1;
        prev = null;
        tail = this;
      }
      else {
        long count = shifts;
        BigNumberImpl temp = this;
        if( shifts < this.length/2){
          while(count > 0){
            this.tail = this.tail.prev;
            count--;
          }
          this.tail.next = null;
        } else {
          while((length - count) > 1){
            temp = temp.next;
            count++;
          }
          temp.next = null;
        }
        this.length -= shifts;
      }

    }
  }

  // rewrite this
  @Override
  public void addDigit(int digit) {
    if (digit > 9 || digit < 0) {
      throw new IllegalArgumentException("The digit should be a single non negative integer.");
    }

    BigNumberImpl temp = addTwoNumbers(this, new BigNumberImpl(String.valueOf(digit)));
    this.number = temp.number;
    this.next = temp.next;
    this.tail = temp.tail;
    this.prev = null;
  }


  @Override
  public int getDigitAt(int index) {
    int currentLength = this.length();
    int digit = 0;
    int currentIndex = (currentLength - index);
    if (currentIndex > currentLength || currentIndex <= 0) {
      throw new IllegalArgumentException("The given index is not valid.");
    }
    BigNumberImpl current = this;
    int count = 1;
    while (current != null) {
      if (count == currentIndex) {
        return current.number;
      }
      count++;
      current = current.next;
    }
    return digit;
  }

  @Override
  public int compareTo(BigNumber newNumber) {
    if (this.length() > newNumber.length()) {
      return 1;
    } else if (this.length() < newNumber.length()) {
      return -1;
    } else {
      return 0;
    }
  }

  @Override
  public BigNumber copy() {
    BigNumber newCopy = new BigNumberImpl(this.toString());
    return newCopy;
  }

  @Override
  public BigNumber add(BigNumber other) {
    BigNumber test = addTwoNumbers(this, other);
    return test;
  }

  private BigNumberImpl addTwoNumbers(BigNumberImpl l1, BigNumber list2) {
    BigNumberImpl l2 = (BigNumberImpl) list2;
    BigNumberImpl add = new BigNumberImpl();
    if(l1 == null){
      return l2;
    }
    if(l2 == null){
      return l1;
    }
    BigNumberImpl tail1 = l1.tail;
    BigNumberImpl tail2 = l2.tail;
    int carry = 0;
    int len = 0;
    while(tail1 != null || tail2 != null || carry != 0 ){
      int x = (tail1 != null) ? tail1.number : 0;
      int y = (tail2 != null) ? tail2.number : 0;
      int sum = x + y + carry;
      carry = sum/10;
      add.number = sum%10;
      if(tail1 != null){
        tail1 = tail1.prev;
      }
      if(tail2 != null){
        tail2 = tail2.prev;
      }
      BigNumberImpl temp = new BigNumberImpl();
      temp.next = add;
      add = temp;
      len++;
    }
    add = add.next;
    add.length = len;
    return add;
  }

  private BigNumberImpl paddWithZeros(BigNumberImpl node, int lenDiff) {

    while (lenDiff > 0) {

      BigNumberImpl newNode = new BigNumberImpl("0");
      newNode.next = node;
      node = newNode;

      lenDiff--;
    }
    return node;
  }

  private BigNumberImpl addTwoNumbersUtil(BigNumberImpl l1, BigNumberImpl l2,
      BigNumberImpl result) {

    if (l1 == null && l2 == null) {
      return result;

    } else {
      result = addTwoNumbersUtil(l1.next, l2.next, result);

      int sum = l1.number + l2.number + result.number;
      int carry = sum / 10;
      sum = sum % 10;
      result.number = sum;
      BigNumberImpl carryNode = new BigNumberImpl(String.valueOf(carry));
      carryNode.next = result;
      result = carryNode;

      return result;

    }


  }

}


